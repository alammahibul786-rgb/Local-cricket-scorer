# Local Cricket Scorer — Android v2.0

A Kotlin + Jetpack Compose Android Studio starter project.

## New in version 2
- Multiple tournaments, each with its own season/year
- Add multiple teams to each tournament
- Add players to each team
- Local persistence for tournament/team/player setup using Android SharedPreferences
- Bottom navigation: Tournaments, Teams, Scorer
- Manual ball-by-ball scoring prototype
- Runs, wides, no-balls, byes, leg-byes, wickets, over count, run rate, undo

## Build
1. Install Android Studio (recent stable version) and JDK 17.
2. Extract this ZIP and open the `LocalCricketScorerV2` folder in Android Studio.
3. Allow Gradle sync to complete.
4. Connect an Android phone or start an emulator, then press Run.
5. To create an APK, use Build > Build Bundle(s) / APK(s) > Build APK(s).

## Important limitations
This project is a development starter and has not been compiled or device-tested in this environment. Tournament, team and player setup is saved locally on the device. Match score state is currently in-memory and resets when the app process is restarted. This version does not yet implement full player-wise batting/bowling scorecards, strike rotation, a second innings, fixtures, points table or NRR. These are planned next.
