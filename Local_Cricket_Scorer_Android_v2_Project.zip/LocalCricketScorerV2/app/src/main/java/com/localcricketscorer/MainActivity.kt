package com.localcricketscorer

import android.os.Bundle
import android.content.Context
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.foundation.text.KeyboardOptions
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.input.KeyboardType
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import org.json.JSONArray
import org.json.JSONObject

private val Forest = Color(0xFF123B2B)
private val Lime = Color(0xFFB8F36B)
private val Page = Color(0xFFF3F7F2)

data class Player(val name: String)
data class Team(val name: String, val players: List<Player> = emptyList())
data class Tournament(val name: String, val season: String, val teams: List<Team> = emptyList())
data class Delivery(val label: String, val runs: Int, val legal: Boolean, val wicket: Boolean = false)
data class Innings(
    val runs: Int = 0, val wickets: Int = 0, val legalBalls: Int = 0,
    val fours: Int = 0, val sixes: Int = 0, val wides: Int = 0,
    val noBalls: Int = 0, val byes: Int = 0, val legByes: Int = 0,
    val balls: List<Delivery> = emptyList()
)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContent { LocalCricketApp(this) }
    }
}

private fun loadTournaments(context: Context): List<Tournament> {
    val raw = context.getSharedPreferences("local_cricket", Context.MODE_PRIVATE)
        .getString("tournaments", "[]") ?: "[]"
    return try {
        val arr = JSONArray(raw)
        (0 until arr.length()).map { i ->
            val t = arr.getJSONObject(i)
            val teamArr = t.optJSONArray("teams") ?: JSONArray()
            val teams = (0 until teamArr.length()).map { j ->
                val tm = teamArr.getJSONObject(j)
                val pa = tm.optJSONArray("players") ?: JSONArray()
                Team(tm.optString("name"), (0 until pa.length()).map { k -> Player(pa.optString(k)) })
            }
            Tournament(t.optString("name"), t.optString("season"), teams)
        }
    } catch (_: Exception) { emptyList() }
}

private fun saveTournaments(context: Context, tournaments: List<Tournament>) {
    val arr = JSONArray()
    tournaments.forEach { t ->
        val teamArr = JSONArray()
        t.teams.forEach { team ->
            val players = JSONArray()
            team.players.forEach { players.put(it.name) }
            teamArr.put(JSONObject().put("name", team.name).put("players", players))
        }
        arr.put(JSONObject().put("name", t.name).put("season", t.season).put("teams", teamArr))
    }
    context.getSharedPreferences("local_cricket", Context.MODE_PRIVATE)
        .edit().putString("tournaments", arr.toString()).apply()
}

@Composable
fun LocalCricketApp(context: Context) {
    var tournaments by remember { mutableStateOf(loadTournaments(context)) }
    var selectedTournament by remember { mutableIntStateOf(-1) }
    var page by remember { mutableStateOf("Tournaments") }
    var tournamentName by remember { mutableStateOf("") }
    var season by remember { mutableStateOf("2026") }
    var teamName by remember { mutableStateOf("") }
    var playerName by remember { mutableStateOf("") }
    var selectedTeam by remember { mutableIntStateOf(-1) }
    var innings by remember { mutableStateOf(Innings()) }
    var undoStack by remember { mutableStateOf(listOf<Innings>()) }
    var oversLimit by remember { mutableIntStateOf(20) }
    var battingTeam by remember { mutableStateOf("Select batting team") }

    fun persist(updated: List<Tournament>) {
        tournaments = updated
        saveTournaments(context, updated)
    }
    val current = tournaments.getOrNull(selectedTournament)
    val legalOver = "${innings.legalBalls / 6}.${innings.legalBalls % 6}"
    val done = innings.wickets >= 10 || innings.legalBalls >= oversLimit * 6

    fun addDelivery(d: Delivery) {
        if (done) return
        undoStack = undoStack + innings
        innings = innings.copy(
            runs = innings.runs + d.runs,
            wickets = innings.wickets + if (d.wicket) 1 else 0,
            legalBalls = innings.legalBalls + if (d.legal) 1 else 0,
            fours = innings.fours + if (d.label == "4") 1 else 0,
            sixes = innings.sixes + if (d.label == "6") 1 else 0,
            wides = innings.wides + if (d.label == "WD") 1 else 0,
            noBalls = innings.noBalls + if (d.label == "NB") 1 else 0,
            byes = innings.byes + if (d.label.startsWith("B")) d.runs else 0,
            legByes = innings.legByes + if (d.label.startsWith("LB")) d.runs else 0,
            balls = innings.balls + d
        )
    }

    MaterialTheme(colorScheme = lightColorScheme(primary = Forest, secondary = Color(0xFFED9B30), background = Page)) {
        Scaffold(
            containerColor = Page,
            bottomBar = {
                NavigationBar(containerColor = Color.White) {
                    listOf("Tournaments", "Teams", "Scorer").forEach { item ->
                        NavigationBarItem(
                            selected = page == item,
                            onClick = { page = item },
                            icon = { Text(when (item) { "Tournaments" -> "🏆"; "Teams" -> "👥"; else -> "🏏" }) },
                            label = { Text(item) }
                        )
                    }
                }
            }
        ) { padding ->
            when (page) {
                "Tournaments" -> LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item {
                        Header("LOCAL CRICKET SCORER", "Manage separate tournaments and seasons")
                    }
                    item {
                        Card(shape = RoundedCornerShape(18.dp)) {
                            Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                Text("CREATE TOURNAMENT", fontWeight = FontWeight.Bold, color = Forest)
                                OutlinedTextField(tournamentName, { tournamentName = it }, label = { Text("Tournament name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                OutlinedTextField(season, { season = it }, label = { Text("Season / year") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                Button(
                                    onClick = {
                                        if (tournamentName.isNotBlank()) {
                                            val updated = tournaments + Tournament(tournamentName.trim(), season.trim())
                                            persist(updated)
                                            selectedTournament = updated.lastIndex
                                            tournamentName = ""
                                            page = "Teams"
                                        }
                                    },
                                    modifier = Modifier.fillMaxWidth()
                                ) { Text("＋ Create tournament") }
                            }
                        }
                    }
                    item { Text("YOUR TOURNAMENTS (${tournaments.size})", color = Forest, fontWeight = FontWeight.Bold) }
                    items(tournaments.indices.toList()) { index ->
                        val t = tournaments[index]
                        Card(shape = RoundedCornerShape(16.dp)) {
                            Row(Modifier.fillMaxWidth().padding(14.dp), verticalAlignment = Alignment.CenterVertically) {
                                Column(Modifier.weight(1f)) {
                                    Text(t.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                    Text("${t.season} • ${t.teams.size} teams", color = Color.Gray, fontSize = 12.sp)
                                }
                                Button(onClick = { selectedTournament = index; page = "Teams" }) { Text("Open") }
                            }
                        }
                    }
                    if (tournaments.isEmpty()) item { Text("No tournaments yet. Create your first tournament above.", color = Color.Gray) }
                }
                "Teams" -> LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Header("TEAMS & PLAYERS", current?.name ?: "Select or create a tournament first") }
                    if (current == null) {
                        item { Text("Go to Tournaments and create or open a tournament.", color = Color.Gray) }
                    } else {
                        item {
                            Card(shape = RoundedCornerShape(18.dp)) {
                                Column(Modifier.padding(16.dp), verticalArrangement = Arrangement.spacedBy(10.dp)) {
                                    Text("ADD TEAM", fontWeight = FontWeight.Bold, color = Forest)
                                    OutlinedTextField(teamName, { teamName = it }, label = { Text("Team name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                    Button(onClick = {
                                        if (teamName.isNotBlank()) {
                                            val updated = tournaments.toMutableList()
                                            updated[selectedTournament] = current.copy(teams = current.teams + Team(teamName.trim()))
                                            persist(updated); teamName = ""
                                        }
                                    }, modifier = Modifier.fillMaxWidth()) { Text("＋ Add team") }
                                }
                            }
                        }
                        items(current.teams.indices.toList()) { index ->
                            val team = current.teams[index]
                            Card(shape = RoundedCornerShape(16.dp)) {
                                Column(Modifier.padding(14.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Row(verticalAlignment = Alignment.CenterVertically) {
                                        Column(Modifier.weight(1f)) {
                                            Text(team.name, fontWeight = FontWeight.Bold, fontSize = 17.sp)
                                            Text("${team.players.size} players", color = Color.Gray, fontSize = 12.sp)
                                        }
                                        TextButton(onClick = { selectedTeam = if (selectedTeam == index) -1 else index }) {
                                            Text(if (selectedTeam == index) "Close" else "Manage players")
                                        }
                                    }
                                    if (selectedTeam == index) {
                                        OutlinedTextField(playerName, { playerName = it }, label = { Text("Player name") }, modifier = Modifier.fillMaxWidth(), singleLine = true)
                                        Button(onClick = {
                                            if (playerName.isNotBlank()) {
                                                val updated = tournaments.toMutableList()
                                                val teams = current.teams.toMutableList()
                                                teams[index] = team.copy(players = team.players + Player(playerName.trim()))
                                                updated[selectedTournament] = current.copy(teams = teams)
                                                persist(updated); playerName = ""
                                            }
                                        }, modifier = Modifier.fillMaxWidth()) { Text("＋ Add player") }
                                        team.players.forEachIndexed { pIndex, p ->
                                            Text("${pIndex + 1}. ${p.name}", fontSize = 14.sp)
                                        }
                                    }
                                }
                            }
                        }
                    }
                }
                else -> LazyColumn(
                    modifier = Modifier.fillMaxSize().padding(padding),
                    contentPadding = PaddingValues(16.dp),
                    verticalArrangement = Arrangement.spacedBy(12.dp)
                ) {
                    item { Header("LIVE MATCH SCORER", current?.name ?: "Select a tournament first") }
                    if (current == null || current.teams.isEmpty()) {
                        item { Text("Create a tournament and add at least one team in the Teams tab before scoring.", color = Color.Gray) }
                    } else {
                        item {
                            Card(shape = RoundedCornerShape(22.dp), colors = CardDefaults.cardColors(containerColor = Forest)) {
                                Column(Modifier.fillMaxWidth().padding(18.dp)) {
                                    Text("INNINGS SCORE", color = Lime, fontWeight = FontWeight.Bold)
                                    Text("$battingTeam  ${innings.runs}/${innings.wickets}", color = Color.White, fontSize = 29.sp, fontWeight = FontWeight.Black)
                                    Text("Overs $legalOver / $oversLimit   •   RR ${if (innings.legalBalls == 0) "0.00" else "%.2f".format(innings.runs * 6f / innings.legalBalls)}", color = Color(0xFFC9E8D5))
                                    Text("4s: ${innings.fours}    6s: ${innings.sixes}", color = Color.White)
                                }
                            }
                        }
                        item {
                            Text("Batting team", fontWeight = FontWeight.Bold)
                            current.teams.forEach { team ->
                                FilterChip(selected = battingTeam == team.name, onClick = { battingTeam = team.name }, label = { Text(team.name) })
                            }
                        }
                        item {
                            Text("Overs limit", fontWeight = FontWeight.Bold)
                            Row(horizontalArrangement = Arrangement.spacedBy(4.dp)) {
                                listOf(5, 10, 12, 16, 20, 25, 50).forEach { n ->
                                    FilterChip(selected = oversLimit == n, onClick = { oversLimit = n }, label = { Text("$n") })
                                }
                            }
                        }
                        item { Text("RUNS", fontWeight = FontWeight.Bold, color = Forest) }
                        item {
                            Row(horizontalArrangement = Arrangement.spacedBy(7.dp)) {
                                listOf(0, 1, 2, 3, 4, 6).forEach { n ->
                                    Button(onClick = { addDelivery(Delivery("$n", n, true)) }, enabled = !done, modifier = Modifier.weight(1f), contentPadding = PaddingValues(0.dp)) { Text("$n", fontWeight = FontWeight.Bold) }
                                }
                            }
                        }
                        item { Text("EXTRAS & WICKET", fontWeight = FontWeight.Bold, color = Forest) }
                        item {
                            Column(verticalArrangement = Arrangement.spacedBy(8.dp)) {
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { addDelivery(Delivery("WD", 1, false)) }, enabled = !done, modifier = Modifier.weight(1f)) { Text("Wide +1") }
                                    Button(onClick = { addDelivery(Delivery("NB", 1, false)) }, enabled = !done, modifier = Modifier.weight(1f)) { Text("No Ball +1") }
                                }
                                Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
                                    Button(onClick = { addDelivery(Delivery("B1", 1, true)) }, enabled = !done, modifier = Modifier.weight(1f)) { Text("Bye +1") }
                                    Button(onClick = { addDelivery(Delivery("LB1", 1, true)) }, enabled = !done, modifier = Modifier.weight(1f)) { Text("Leg Bye +1") }
                                }
                                Button(onClick = { addDelivery(Delivery("W", 0, true, true)) }, enabled = !done, modifier = Modifier.fillMaxWidth(), colors = ButtonDefaults.buttonColors(containerColor = Color(0xFFB3261E))) { Text("WICKET") }
                            }
                        }
                        item {
                            Row(verticalAlignment = Alignment.CenterVertically, horizontalArrangement = Arrangement.SpaceBetween, modifier = Modifier.fillMaxWidth()) {
                                Text("Recent deliveries", fontWeight = FontWeight.Bold)
                                TextButton(onClick = {
                                    if (undoStack.isNotEmpty()) { innings = undoStack.last(); undoStack = undoStack.dropLast(1) }
                                }, enabled = undoStack.isNotEmpty()) { Text("Undo") }
                            }
                            Text(innings.balls.takeLast(15).joinToString("  ") { it.label }.ifEmpty { "No deliveries yet" })
                        }
                        item {
                            Card {
                                Column(Modifier.padding(14.dp)) {
                                    Text("INNINGS TOTALS", fontWeight = FontWeight.Bold, color = Forest)
                                    Text("Wides: ${innings.wides}   No-balls: ${innings.noBalls}")
                                    Text("Byes: ${innings.byes}   Leg-byes: ${innings.legByes}")
                                    Text("Legal balls: ${innings.legalBalls}")
                                }
                            }
                        }
                        item {
                            OutlinedButton(onClick = { innings = Innings(); undoStack = emptyList() }, modifier = Modifier.fillMaxWidth()) { Text("Reset innings") }
                            if (done) Text("Innings completed", color = Forest, fontWeight = FontWeight.Bold)
                        }
                    }
                }
            }
        }
    }
}

@Composable
private fun Header(title: String, subtitle: String) {
    Column(
        Modifier.fillMaxWidth().background(Forest, RoundedCornerShape(22.dp)).padding(18.dp),
        verticalArrangement = Arrangement.spacedBy(5.dp)
    ) {
        Text("🏏  $title", color = Lime, fontWeight = FontWeight.Black, fontSize = 17.sp)
        Text(subtitle, color = Color.White, fontSize = 13.sp)
    }
}
