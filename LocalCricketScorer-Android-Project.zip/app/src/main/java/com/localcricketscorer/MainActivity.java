package com.localcricketscorer;

import android.app.Activity;
import android.app.AlertDialog;
import android.graphics.Color;
import android.graphics.Typeface;
import android.os.Bundle;
import android.view.Gravity;
import android.view.View;
import android.widget.*;

import java.util.ArrayDeque;
import java.util.Locale;

public class MainActivity extends Activity {
    int runs = 0, wickets = 0, legalBalls = 0, extras = 0;
    int fours = 0, sixes = 0;
    final ArrayDeque<int[]> undo = new ArrayDeque<>();
    TextView scoreText, overText, detailText, statusText;
    LinearLayout root;

    @Override public void onCreate(Bundle b) {
        super.onCreate(b);
        getWindow().setStatusBarColor(Color.rgb(13, 76, 55));
        getWindow().setNavigationBarColor(Color.rgb(13, 76, 55));
        buildScreen();
        refresh();
    }

    int dp(int v) { return (int)(v * getResources().getDisplayMetrics().density); }

    TextView text(String s, int size, int color, boolean bold) {
        TextView t = new TextView(this);
        t.setText(s); t.setTextSize(size); t.setTextColor(color);
        if (bold) t.setTypeface(null, Typeface.BOLD);
        return t;
    }

    LinearLayout row() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER);
        l.setPadding(0, dp(4), 0, dp(4));
        return l;
    }

    void buildScreen() {
        ScrollView scroll = new ScrollView(this);
        root = new LinearLayout(this);
        root.setOrientation(LinearLayout.VERTICAL);
        root.setPadding(dp(16), dp(14), dp(16), dp(20));
        root.setBackgroundColor(Color.rgb(245,248,246));
        scroll.addView(root);
        setContentView(scroll);

        TextView title = text("LOCAL CRICKET SCORER", 22, Color.WHITE, true);
        title.setGravity(Gravity.CENTER);
        title.setPadding(dp(10), dp(20), dp(10), dp(20));
        title.setBackgroundColor(Color.rgb(13,76,55));
        root.addView(title);

        TextView sub = text("MANUAL BALL-BY-BALL SCORING", 12, Color.rgb(80,100,90), true);
        sub.setGravity(Gravity.CENTER);
        sub.setPadding(0, dp(12), 0, dp(8));
        root.addView(sub);

        LinearLayout scoreCard = new LinearLayout(this);
        scoreCard.setOrientation(LinearLayout.VERTICAL);
        scoreCard.setGravity(Gravity.CENTER);
        scoreCard.setPadding(dp(12), dp(18), dp(12), dp(18));
        scoreCard.setBackgroundColor(Color.rgb(13,76,55));
        scoreText = text("", 42, Color.WHITE, true); scoreText.setGravity(Gravity.CENTER);
        overText = text("", 18, Color.WHITE, true); overText.setGravity(Gravity.CENTER);
        detailText = text("", 14, Color.rgb(220,240,225), false); detailText.setGravity(Gravity.CENTER);
        scoreCard.addView(scoreText); scoreCard.addView(overText); scoreCard.addView(detailText);
        root.addView(scoreCard);

        statusText = text("Tap a button to record each delivery.", 14, Color.DKGRAY, false);
        statusText.setPadding(0, dp(12), 0, dp(8)); root.addView(statusText);

        addSection("RUNS");
        addButtons(new String[]{"0","1","2","3","4","6"}, new int[]{0,1,2,3,4,6}, "run");

        addSection("EXTRAS");
        addButtons(new String[]{"Wide +1","No-ball +1","Bye +1","Leg bye +1"}, new int[]{1,1,1,1}, "extra");

        addSection("WICKET");
        Button wicket = makeButton("WICKET", Color.rgb(183,45,55));
        wicket.setOnClickListener(v -> record(0, "wicket"));
        root.addView(wicket);

        addSection("MATCH CONTROLS");
        LinearLayout controls = row();
        Button undoBtn = makeButton("UNDO", Color.rgb(65,85,105));
        undoBtn.setOnClickListener(v -> undoLast());
        controls.addView(undoBtn, weight());
        Button resetBtn = makeButton("NEW INNINGS", Color.rgb(25,115,145));
        resetBtn.setOnClickListener(v -> confirmReset());
        controls.addView(resetBtn, weight());
        root.addView(controls);

        TextView note = text("Note: This starter version tracks the team total, wickets, legal overs, boundaries and extras. Batter/bowler names and full scorecards can be added in the next version.", 12, Color.GRAY, false);
        note.setPadding(0, dp(16), 0, 0); root.addView(note);
    }

    LinearLayout.LayoutParams weight() {
        return new LinearLayout.LayoutParams(0, dp(50), 1f);
    }

    void addSection(String s) {
        TextView t = text(s, 14, Color.rgb(13,76,55), true);
        t.setPadding(0, dp(16), 0, dp(4)); root.addView(t);
    }

    Button makeButton(String label, int color) {
        Button b = new Button(this);
        b.setText(label); b.setTextColor(Color.WHITE);
        b.setAllCaps(false); b.setTextSize(15);
        b.setBackgroundTintList(android.content.res.ColorStateList.valueOf(color));
        return b;
    }

    void addButtons(String[] labels, int[] vals, String type) {
        int perRow = 3;
        for (int start=0; start<labels.length; start+=perRow) {
            LinearLayout r = row();
            for (int j=start; j<Math.min(start+perRow, labels.length); j++) {
                final int value=vals[j]; final String label=labels[j];
                Button b=makeButton(label, type.equals("run") ? Color.rgb(24,132,88) : Color.rgb(36,112,150));
                LinearLayout.LayoutParams p=weight(); p.setMargins(dp(3),dp(3),dp(3),dp(3));
                r.addView(b,p);
                b.setOnClickListener(v -> record(value, type.equals("run") ? "run" : label));
            }
            root.addView(r);
        }
    }

    void saveState() {
        undo.push(new int[]{runs,wickets,legalBalls,extras,fours,sixes});
    }

    void record(int value, String type) {
        saveState();
        if (type.equals("wicket")) {
            wickets++;
            legalBalls++;
            statusText.setText("Wicket recorded.");
        } else if (type.equals("run")) {
            runs += value;
            legalBalls++;
            if (value == 4) fours++;
            if (value == 6) sixes++;
            statusText.setText(value + (value == 1 ? " run" : " runs") + " recorded.");
        } else {
            runs += value;
            extras += value;
            if (type.startsWith("Wide")) {
                statusText.setText("Wide recorded (+1). Ball does not count.");
            } else if (type.startsWith("No-ball")) {
                statusText.setText("No-ball recorded (+1). Ball does not count.");
            } else {
                legalBalls++;
                statusText.setText(type + " recorded.");
            }
        }
        refresh();
    }

    void undoLast() {
        if (undo.isEmpty()) {
            statusText.setText("Nothing to undo.");
            return;
        }
        int[] s=undo.pop();
        runs=s[0]; wickets=s[1]; legalBalls=s[2]; extras=s[3]; fours=s[4]; sixes=s[5];
        statusText.setText("Last action undone.");
        refresh();
    }

    void refresh() {
        scoreText.setText(runs + "/" + wickets);
        overText.setText(String.format(Locale.US, "%d.%d overs", legalBalls/6, legalBalls%6));
        detailText.setText("Extras: " + extras + "     4s: " + fours + "     6s: " + sixes);
    }

    void confirmReset() {
        new AlertDialog.Builder(this)
            .setTitle("Start a new innings?")
            .setMessage("This clears the current innings score.")
            .setNegativeButton("Cancel", (d,w) -> d.dismiss())
            .setPositiveButton("Start", (d,w) -> {
                runs=0; wickets=0; legalBalls=0; extras=0; fours=0; sixes=0;
                undo.clear(); statusText.setText("New innings started."); refresh();
            }).show();
    }
}
